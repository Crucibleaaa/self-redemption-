# 实证实验复现包 (R163 实证链, 2026-08)

本目录集中 llm_research_v5 的实证实验: 脚本 + 结果档案 + 复现命令。
配套理论档案: `src/relative-recursion/formal/claims/Toolkit/R163.yaml`
(实证记录 I4b–I7g 与本文档一一对应)。

**方法论**: `METHODOLOGY.md` — 标准消融 × 结构直觉对比 × 对比样本设计
(后续所有分析按此执行); `scripts/template_exp.py` — 标准实验模板
(`run_standard(label, chain_fn)`, 训练+OOD+多 seed+留出, 自检通过)。

## 环境

- venv: `/home/ethanw/llm-research/.venv` (uv 管理)
- 运行目录: `src/llm_research_v5/` (脚本 import 相对 lab/)
- 命令模板:
  ```bash
  cd src/llm_research_v5
  PYTHONPATH=$HOME/llm-research/.venv/lib/python3.14/site-packages:. \
    python3 lab/paper_repro/scripts/<脚本> > /tmp/<out>.txt 2>&1
  ```
- 引擎依赖 (已入主库, 复现无需改动):
  - `tokenizer/eval/symmetry_eval.py::mod_domain(N)` — mod 域 (ℤ/N,
    reciprocal = 乘法逆元, 扩展欧几里得)
  - `tokenizer/eval/engine.py::_ring` — 基础算子环归约 (mod 域)
  - `train/data.py::vocab` — 支持被概念定义引用/箭头 source-target 的
    S 层符号 (sign 家族迁移后必需)
  - token 迁移 (2026-08-15): sign/sign_pos/sign_neg 从 C 层移入 S 层
    (S:392–394); C 层只留正负性概念
- 训练配置: dim=64, layers=2, epochs=60, seed 固定 (0,1,2)
- 判定口径: 完整序列逐 token 重建全对 (末尾真值判定可信口径)

## 实验索引

| 编号 | 脚本 | 目的 | 结果 (R163 条目) |
|---|---|---|---|
| E1 | ablate_channels.py | 三通道摘除消融 (样本×构造×箭头, mod 域 ℤ/7): 恢复判定严格化 | I4/I4b |
| E2 | sym_map_exp.py | 符号映射: 裸符号→概念 (跨层) vs 概念→概念 (同层) | I5 |
| E3 | succ_nest_exp.py | 纯结构嵌套 (4 token: zero/succ/+/×): 收敛+外推+0 组合 | I7/I7b |
| E4 | zero_exp.py | 四种 0 定义 (公设/结构/直觉/相对) | I7c |
| E5 | zero_succ_exp.py | 0 的 4 种 × succ 的 2 种 = 8 组矩阵 | I7d |
| E6 | zero_symbol_exp.py | 结构直觉 vs 符号 token (含 numeral 直觉路径/显式位置) | I7e |
| E7 | zero_hole_exp.py | 0 组合留出: 部分 0 训练, 部分 0 不训练测外推 | I7f |
| E8 | zero_vs_nz_exp.py | 0 乘法 vs 非零乘法对比 (0 零样本外推) | I7g |
| E9 | succ_shift_exp.py | succ 平移不变性: 只训 succ(0), 外推 succ(1..7); value_zero 错题 | I7h |
| E10 | axis_succ_exp.py | 不同轴 succ + 单轴消融 (跨轴迁移) | I7i |
| E11 | basepoint_drift_exp.py | 基点漂移对比: 零样本/双锚/显式穿折越桥接 | I7j/I7k |
| E12 | succ_matrix_exp.py | succ 结构矩阵: 同基点 2 succ + 等价声明桥接 + 对称性专用 | I7q |
| E13 | succ_disc_exp.py | 差异题 (混淆对): 2×2 vs 2+2, 0×2 vs 0+2 运算区分外推 | I7r |

## 结果总表 (2026-08-15)

| 实验 | 训练 | OOD 外推 | 结论 |
|---|---|---|---|
| E3 纯结构嵌套 | 1.000 × 5 seeds | 36/36 + 0 组合 60/60 × 4 seeds | 同构嵌套底座稳 |
| E4 四种 0 | 1.000 × 12 次 | 全过 | 0 的定义方式对训练不可见 |
| E5 8 组 0×succ | 1.000 × 24 次 | 全过 | succ 显式/隐式对训练不可见 |
| E6 结构 vs 符号 | A/C 1.000 | A/C 30/30 稳; B/D 0/30 崩 | 位置-值需结构承载; 真 numeral = 基点 succ 链 (A) |
| E7 0 留出 | 全训 1.000 | 留出组: 未训 0 组合 40/40 + 远 OOD 24/24 | 0 吸收律从 5 个 0 样本外推到 0×5..0×9 |
| E8 0 vs 非零 | 非零训 1.000 | **0 零样本外推 45/45** (与混训无差异) | 0 乘法无需训练样本 — 链长乘法规则自然外推 |
| E9 succ 平移 | 只训 succ(0) 1.000 | **succ(1..7) 14/14** (2 样本外推) | 0→1 与 1→2 是同一个 succ (平移不变); 0 错题无差异 |
| E10 多轴 succ | 双轴/单轴 1.000 | 单轴消融: 同轴 12/12, **跨轴 0/12** | 轴内同一性 vs 跨轴零迁移 — 每轴 succ 独立, 单轴可消融 |
| E11 基点漂移 | 锚0/双锚 1.000 | 同锚 32/32, **漂移 0/32, 显式桥接 0/32** | 运算是锚绑定的 — 穿折越等价不传递运算, 每参考系需独立实证 |
| E12 succ 矩阵 | 1.000 | 同锚等价声明桥接 **0/32→32/32**; 跨锚 0/32 | 锚是结构身份, succ 是同锚下可翻译记法 |
| E13 差异题 | 1.000 | 混淆对 OOD **56/56** (0×5 vs 0+5, 5×5 vs 5+5) | 运算区分在表示内外推稳定 (直觉路径观察) |

## 关键结论 (论文素材)

1. **同构嵌套可学习**: 纯概念 4 token (zero/succ/addition/multiplication),
   succ 嵌套表示, 加乘含 0 全枚举 — 收敛 + 外推到训练外数字
   (长度外推), 多 seed 稳定.
2. **定义层对训练不可见**: 0 的 4 种定义 (公设/迭代零点/缺省/对消律)
   与 succ 的 2 种设计 (显式概念/原子计数) 全部等价 — 训练直觉
   只看表示形式 (序列结构), token 定义层 (语义来源) 不可见.
3. **位置-值必须结构承载**: 裸符号序列 (位置不变数值变) 无法外推;
   numeral 结构 (base/cardinality 槽 + digit 排序 = 位权) 是位置-值的
   直觉路径, 稳定外推; 名义位置 token (place 标记) 不承载位权语义.
4. **符号/概念严格分离**: 符号 (S 层) 是书写投影, 概念 (C 层) 承载
   结构; 符号必须映射到结构化概念 (经 numeral 结构), 裸符号直映不稳
   (模型混淆符号与概念 token 的直接证据: 消融 seed=1 探针 inversion
   槽输出 sign_pos).

## 复现顺序

1. E3 (底座) → 2. E4/E5 (定义层不可见) → 3. E6 (结构承载) → 4. E7 (0 留出)
每实验 3–5 seeds, 单次运行 2–10 分钟 (dim=64 小模型).
